#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

void error(const char *msg)
{
    perror(msg);
    exit(1);
} // Error function used for reporting issues


int charToInt(char c){
  char array[27] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ ";
  int i;
  for(i = 0; i < 27; i++){
    if(array[i] == c)
      break;
  }
  i++;
  return i;
}
//convert int to char
char intToChar(int i){
  char array[27] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ ";
  return array[i-1];
}

int main(int argc, char *argv[])
{
    int listenSocketFD, establishedConnectionFD, portNumber, charsRead, status = -5, childSum = 0, charsWritten;
    socklen_t sizeOfClientInfo;
    char buffer[100000], textBuffer[100000], keyBuffer[100000];
    struct sockaddr_in serverAddress, clientAddress;
    pid_t PID, wPID;
    char encText[1100000];

    if (argc < 2)
    {
        fprintf(stderr, "USAGE: %s port\n", argv[0]);
        exit(1);
    } // Check usage & args

    // Set up the address struct for this process (the server)
    memset((char *)&serverAddress, '\0', sizeof(serverAddress)); // Clear out the address struct
    portNumber = atoi(argv[1]);                                  // Get the port number, convert to an integer from a string
    serverAddress.sin_family = AF_INET;                          // Create a network-capable socket
    serverAddress.sin_port = htons(portNumber);                  // Store the port number
    serverAddress.sin_addr.s_addr = INADDR_ANY;                  // Any address is allowed for connection to this process

    // Set up the socket
    listenSocketFD = socket(AF_INET, SOCK_STREAM, 0); // Create the socket
    if (listenSocketFD < 0)
        error("ERROR opening socket");

    // Enable the socket to begin listening
    if (bind(listenSocketFD, (struct sockaddr *)&serverAddress, sizeof(serverAddress)) < 0) // Connect socket to port
        error("ERROR on binding");
    listen(listenSocketFD, 5); // Flip the socket on - it can now receive up to 5 connections

    while (1)
    {

        while ((wPID = waitpid(-1, &status, WNOHANG)) > 0)
            childSum--;
        // when number of child less than 5, do stuffs.
        if (childSum < 5)
        {
            // printf("d in child sum <5\n");
            // Accept a connection, blocking if one is not available until one connects
            sizeOfClientInfo = sizeof(clientAddress);                                                               // Get the size of the address for the client that will connect
            establishedConnectionFD = accept(listenSocketFD, (struct sockaddr *)&clientAddress, &sizeOfClientInfo); // Accept
            if (establishedConnectionFD < 0)
                error("ERROR on accept");
            PID = fork();

            if (PID == -1)
            {
                error("Fork failed");
            }
            else if (PID == 0)
            {
                // printf("d in the child process\n");

                // check connection 
                // Get checking message from client
                int bufferposition = 0;
                memset(buffer, '\0', sizeof(buffer)); // Clear out the buffer again for reuse
                do
                {
                    charsWritten = recv(establishedConnectionFD, &buffer[bufferposition], 50, 0); // Read data from the socket
                    if (charsWritten<0)
                    {
                        perror("OTP_ENC: ERROR reading from socket");
                        exit(1);
                    }
                    bufferposition += charsWritten;
                } while (buffer[bufferposition - 1] != 'c');
                //printf("d Before check connection\n");
                //check connection
                if (strstr(buffer, "enc") == NULL)
                {
                    charsWritten = send(establishedConnectionFD, "!@", strlen("!@"), 0);

                        perror("Error: otp_enc_d is not connect with otp_enc");
                        exit(2);
                        //error("ERROR: not connect with otp_enc");

                    close(establishedConnectionFD); // Close the existing socket which is connected to the client
                }
                else
                {
                    charsWritten = send(establishedConnectionFD, "@", strlen("@"), 0);
                }
                


                // Get return message from server
                bufferposition = 0;
                memset(buffer, '\0', sizeof(buffer)); // Clear out the buffer again for reuse
                do
                {
                    charsWritten = recv(establishedConnectionFD, &buffer[bufferposition], 50, 0); // Read data from the socket
                    if (charsWritten<0)
                    {
                        perror("OTP_ENC: ERROR reading from socket");
                        exit(1);
                    }
                    bufferposition += charsWritten;
                } while (buffer[bufferposition - 1] != '@');



                // printf("d Before read text\n");
                int j = 0, textIndex = 0, keyIndex = 0;

                //read until hit '*', which is the sign of the end of text
                do
                {
                    textBuffer[textIndex] = buffer[j];
                    textIndex++;
                    j++;
                } while (buffer[j] != '*');
                textBuffer[textIndex] = '\0';

                //skip the *
                j++;

                //read until hit '@', which is the sign of the end of key
                do
                {
                    keyBuffer[keyIndex] = buffer[j];
                    keyIndex++;
                    j++;
                } while (buffer[j] != '@');
                keyBuffer[keyIndex] = '\0';
                // printf("d key buffer = %s\n",keyBuffer);

                // printf("d Before enc\n");


                //encryced text
                int num,i;
                for (i = 0; textBuffer[i] != '\0'; i++)
                {
                    num = (charToInt(textBuffer[i]) + charToInt(keyBuffer[i]));
                    if (num > 27)
                        num -= 27;
                    textBuffer[i] = intToChar(num);
                }                
                // printf("textBuffer = %s\n",textBuffer);
                // printf("Before send enc\n");


                //send encryced text
                int readLen = 0;
                do
                {
                    charsRead = send(establishedConnectionFD, textBuffer, sizeof(textBuffer), 0);
                    if (charsRead < 0)
                        error("ERROR writing to socket");
                    readLen += charsRead;
                } while (textBuffer[readLen - 1] != '\0');

                close(establishedConnectionFD); // Close the existing socket which is connected to the client
                exit(0);
            }
            else
            {
                childSum++;
            }
        }
        //when have 5 children, wait until one finished
        else
        {
            while ((wPID = waitpid(-1, &status, 0)) > 0)
                childSum--;
        }
    }


    return 0;
}
/*

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

void error(const char *msg)
{
    perror(msg);
    exit(1);
} // Error function used for reporting issues

int main(int argc, char *argv[])
{

    int listenSocketFD, establishedConnectionFD, portNumber, childSum = 0,charsRead,charsWritten;
    int childExitMethod = -5;
    socklen_t sizeOfClientInfo;
    char buffer[1000];
    char textBuffer[1000];
    char keyBuffer[1000];
    char encText[1000];
    pid_t childPID;
    struct sockaddr_in serverAddress, clientAddress;


    if (argc < 2)
    {
        fprintf(stderr, "USAGE: %s port\n", argv[0]);
        exit(1);
    } // Check usage & args

    // Set up the address struct for this process (the server)
    memset((char *)&serverAddress, '\0', sizeof(serverAddress)); // Clear out the address struct
    portNumber = atoi(argv[1]);                                  // Get the port number, convert to an integer from a string
    serverAddress.sin_family = AF_INET;                          // Create a network-capable socket
    serverAddress.sin_port = htons(portNumber);                  // Store the port number
    serverAddress.sin_addr.s_addr = INADDR_ANY;                  // Any address is allowed for connection to this process

    // Set up the socket
    listenSocketFD = socket(AF_INET, SOCK_STREAM, 0); // Create the socket
    if (listenSocketFD < 0)
        error("ERROR opening socket");

    // Enable the socket to begin listening
    if (bind(listenSocketFD, (struct sockaddr *)&serverAddress, sizeof(serverAddress)) < 0)
        error("ERROR on binding"); // Connect socket to port.
    listen(listenSocketFD, 5);     // Flip the socket on - it can now receive up to 5 connections

    // Keep listening until stopped manually
    while (1)
    {

        // check dead child
        while ((childPID = waitpid(-1, &childExitMethod, WNOHANG)) > 0)
            childSum --; 

        // keep child less than 5
        if (childSum < 5)
        {

            // Accept a connection, blocking if one is not available until one connects
            sizeOfClientInfo = sizeof(clientAddress);                                                               // Get the size of the address for the client that will connect
            establishedConnectionFD = accept(listenSocketFD, (struct sockaddr *)&clientAddress, &sizeOfClientInfo); // Accept
            if (establishedConnectionFD < 0)
                error("ERROR on accept");

            // Fork the accepted connection.
            pid_t spawnPID = -5;
            spawnPID = fork();

            // See if we are the parent or child.
            //error
            if(spawnPID==-1)
            {
                perror("Fork failed.\n");
                exit(1);
                break;
            }
            // in the child
            else if (spawnPID==0)
            {


                memset(buffer, '\0', sizeof(buffer));         // Clear our buffer
                memset(textBuffer, '\0', sizeof(textBuffer)); // Clear our textBuffer
                memset(keyBuffer, '\0', sizeof(keyBuffer));   // Clear our keyBuffer
                memset(encText, '\0', sizeof(encText));       // Clear our encText

                // Get the message from the client and display it.
                int bufLen;     // Holds the buffer length.
                int bufSum = 0; // The number of chars we have writen to our buffer
                do
                {
                    charsRead = recv(establishedConnectionFD, &buffer[bufSum], 1000, 0); // Read the client's message from the socket
                    bufSum += charsRead;                                                 // Get the number of chars read and add it to our sum.
                    bufLen = strlen(buffer);                                             // Get the current length of the string in the buffer.
                    if (charsRead < 0)
                        error("ERROR reading from socket");
                } while (buffer[bufLen - 1] != '@'); // Keep reading until we find the @ terminating char.

                // See if otp_enc is trying to connect, otherwise refuse connection.
                if (buffer[0] != 'e' || buffer[1] != '$')
                {
                    charsWritten = send(establishedConnectionFD, "!@", strlen("!@"), 0);
                    if (charsWritten < 0)
                        error("ERROR writing to socket");
                    close(establishedConnectionFD); // Close the existing socket which is connected to the client
                    exit(1);
                }

                // Split buffer up based on special chars.
                int i = 0, j = 0, k = 0, saveMode = 0;
                char tempChar = '\0';
                for (i = 0; buffer[i] != '@'; i++)
                {

                    // after we find '$' we are saving plain text .
                    if (buffer[i] == '$')
                    {
                        saveMode = 1;
                        i++;
                    }

                    // after we find '%' we are saving key text
                    if (buffer[i] == '%')
                    {
                        saveMode = 2;
                        i++;
                    }

                    // If we are looking at the text buffer start saving to textBuffer.
                    if (saveMode == 1)
                    {
                        textBuffer[j] = buffer[i]; // Save the current char.
                        j++;
                    }

                    // If we are looking at the key buffer start saving to keyBuffer.
                    if (saveMode == 2)
                    {
                        keyBuffer[k] = buffer[i]; // Save the current char.
                        k++;
                    }
                }

                // Encrypt
                int valText = 0, valKey = 0, valSum = 0;
                char charArray[29] = "!ABCDEFGHIJKLMNOPQRSTUVWXYZ ";
                for (i = 0; textBuffer[i] != '\0'; i++)
                {

                    // Find the value of plain text char.
                    for (j = 1; charArray[j] != '\0'; j++)
                    {
                        if (textBuffer[i] == charArray[j])
                            valText = j;
                    }

                    // Find the value of key char.
                    for (j = 1; charArray[j] != '\0'; j++)
                    {
                        if (keyBuffer[i] == charArray[j])
                            valKey = j;
                    }

                    // Get the sum of our text and key chars.
                    valSum = valText + valKey; // Get the sum of our two chars.
                    while (valSum > 27)
                        valSum -= 27; // Never let our sum be greater than 27.

                    // Find the encrypted char.
                    for (j = 1; charArray[j] != '\0'; j++)
                    {
                        if (valSum == j)
                            encText[i] = charArray[j]; // Save the current encrypted char.
                    }
                }

                // Send a the encrypted text back to the client
                int encLen = strlen(encText);
                do
                {
                    charsWritten = send(establishedConnectionFD, encText, encLen, 0); // Write to client.
                    if (charsWritten < 0)
                        error("Error: writing to socket");
                } while (charsWritten < encLen);

                do
                {
                    charsWritten = send(establishedConnectionFD, "@", strlen("@"), 0); // Write '@' at the end of our message to client.
                    if (charsWritten < 0)
                        error("Error: writing to socket");
                } while (charsWritten < strlen("@"));

                close(establishedConnectionFD); // Close the existing socket which is connected to the client
            }
            // In the parent
            else
            {
                childSum ++; // Increase the child count.
            }
            
        }
        else
        {
            if ((childPID = waitpid(-1, &childExitMethod, 0)) > 0)
                childSum --; // If we already have five children just wait here for a child to finish and reap it.
        }
    }

    return 0;
}
*/