#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv){
    if (argc!=2) {
        perror("ERROR invalid command line argument\n");
        return 0;
    }
    
    
    int keyLength = atoi(argv[1]),i,temp;
    const char keyCharecter[27] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ ";
    /* Intializes random number generator */
    time_t t;
    srand((unsigned) time(&t));

    if (keyLength>0) {
        char key[keyLength+1];
        for( i = 0; i < keyLength; i++)
        {
            temp = rand() % (int)(sizeof keyCharecter - 1);
            key[i] = keyCharecter[temp];
        }
        key[keyLength] = '\0';
        printf("%s\n",key);
        fflush(stdout);
    }
    else
    {
        perror("Invalid key length\n");
    }
    
    

}