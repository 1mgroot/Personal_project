#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
void main_loop(pid_t parent_pid);
char *read_line();
char **split_line(char *);
int launch(char **, int, int, long *);
int execute(char **, pid_t, int, int, long *);
int bi_exit();
int bi_status(char **argument_array);
void expandDollar(char **argument_array, pid_t parent_pid);
void set_in_out(char **argument_array, int fd[2]);
void kill_zombies(int num_background, long *backgroundPID);
void TSTP_handle(int signal);

int fg = 0; //forground only mode

int main()
{
    //ignore SIGINT
    struct sigaction ignore_action = {0};
    ignore_action.sa_handler = SIG_IGN;
    sigaction(SIGINT, &ignore_action, NULL);
    //create new SIGTSTP signal handler
    struct sigaction TSTP_action = {0};
    TSTP_action.sa_handler = TSTP_handle;
    sigfillset(&TSTP_action.sa_mask);
    TSTP_action.sa_flags = SA_RESTART;

    sigaction(SIGTSTP, &TSTP_action, NULL);
    //initialize STATUS and SIG
    setenv("STATUS", "0", 1);
    setenv("SIG", "0", 1);

    pid_t parent_pid = getpid();

    //initialize STATUS SIG
    setenv("SIG", "0", 1);
    setenv("STATUS", "0", 1);
    main_loop(parent_pid);
    return EXIT_SUCCESS; //add
}

void main_loop(pid_t parent_pid)
{
    int execute_status = 0, terminate = 0, num_background = 0;
    char **argument_array;
    char *line;
    long backgroundPID[102];

    do
    {
        // if terminated, reset it to 0;
        if (terminate)
        {
            bi_status(NULL);
            terminate = 0;
        }

        printf(":");
        
            fflush(stdout);
        //kill zombies
        kill_zombies(num_background, backgroundPID);
        //get input
        line = read_line();
        //split input string to words
        argument_array = split_line(line);
        //excute
        execute_status = execute(argument_array, parent_pid, terminate, num_background, backgroundPID);
        free(line);
        free(argument_array);
    } while (execute_status);
}

char *read_line()
{

    int position = 0;
    char *buffer = malloc(sizeof(char) * 2048);
    int c;

    while (1)
    {
        // Read a character
        c = getchar();

        // If we hit EOF, replace it with a null character and return.
        if (c == EOF || c == '\n')
        {
            buffer[position] = '\0';
            return buffer;
        }
        else
        {
            buffer[position] = c;
        }
        position++;
    }
}

char **split_line(char *line)
{
    char **tokens = malloc(sizeof(char *) * 512);
    char *a_token;
    int index = 0;

        if (!tokens)
    {
        fprintf(stderr, "Cannot declare tokens\n");
        fflush(stdout);
        exit(1);
    }

    //read the line word by word
    a_token = strtok(line, " "); //get the first word of line
    while (a_token != NULL)
    {
        tokens[index] = a_token;
        index++;
        a_token = strtok(NULL, " ");
    }
    tokens[index] = NULL;
    return tokens;
}

void set_in_out(char **argument_array, int fd[2])
{
    int in = 0, out = 0, index = 0;

    //get the index of "<" and ">"
    while (argument_array[index])
    {
        if (strcmp(argument_array[index], "<") == 0)
        {
            in = index;
        }
        else if (strcmp(argument_array[index], ">"))
        {
            out = index;
        }
        index++;
    }
    //set input
    if (in && argument_array[in + 1])
    {
        fd[1] = open(argument_array[in + 1], O_RDONLY);
        if (fd[1] == -1)
        {
            fprintf(stderr, "File can't be opened.\n");
            fflush(stdout);
            exit(1);
        }
        dup2(fd[1], STDIN_FILENO);
        fcntl(fd[1], F_SETFD, FD_CLOEXEC);
        argument_array[in] = NULL;
        argument_array[in + 1] = NULL;
    }
    //set output·
    if (out && argument_array[out + 1])
    {
        fd[0] = open(argument_array[out + 1], O_WRONLY | O_CREAT, 0660);
        if (fd[0] == -1)
        {
            fprintf(stderr, "File can not be opened.\n");
            fflush(stdout);
            exit(1);
        }
        dup2(fd[0], STDOUT_FILENO);
        fcntl(fd[0], F_SETFD, FD_CLOEXEC);
        argument_array[out] = NULL;
        argument_array[out + 1] = NULL;
    }
}

int launch(char **argument_arrays, int ter, int num_background, long *backgroundPID)
{

    pid_t pid, wpid;
    int status, background = 0, i = 0;
    int fd[2];
    char str[15]; //set exit status
    // i = the last index of argument array
    while (argument_arrays[i])
    {
        i++;
    }
    i -= 1;

    if (strcmp(argument_arrays[i], "&") == 0)
    {
        argument_arrays[i] = NULL;
        //if not in the forground only mode, set background = 1
        if (!fg)
        {
            background = 1;
        }
    }

    pid = fork(); // copy the process and get the return value, store in pid
    if (pid == 0) //in child
    {
        //if not in the background mode
        if (background == 0)
        {
            struct sigaction default_action = {0};
            default_action.sa_handler = SIG_DFL;
            sigaction(SIGINT, &default_action, NULL);
        }
        //check if the num_backgrounds too big
        else if (background && num_background >= 90)
        {
            fprintf(stderr, "ERROR:Too many background process.\n");
            fflush(stdout);
            exit(1);
        }
        //background mode
        if (background == 1)
        {
            fd[0] = open("/dev/null", O_WRONLY); //redirect stdout and stderror to /dev/null
            dup2(fd[0], STDOUT_FILENO);
            dup2(fd[0], STDERR_FILENO);
            fcntl(fd[0], F_SETFD, FD_CLOEXEC);
            fd[1] = open("/dev/null", O_RDONLY); //redirect stdin to /dev/null
            dup2(fd[1], STDIN_FILENO);
            fcntl(fd[1], F_SETFD, FD_CLOEXEC);
        }

        set_in_out(argument_arrays, fd);

        if (execvp(argument_arrays[0], argument_arrays) == -1) //execute that array and the if-statement will be true when execute command meet error
            perror("error");
        exit(EXIT_FAILURE);
    }
    else if (pid < 0)
    {
        perror("error");
    }
    else
    {
        //parent
        setenv("STATUS", "0", 1); //reset STATUS and SIG
        setenv("SIG", "0", 1);
        if (background)
        {                                                   //if is backgroud process
            printf("background pid is %ld\n", (long)(pid)); //print mesage
            fflush(stdout);
            //add pid to backgrounds array
            backgroundPID[num_background] = pid;
            num_background++;
            return 1;
        }
        do
        {
            // forground, wait the process finish
            wpid = waitpid(pid, &status, WUNTRACED);
        } while (!WIFEXITED(status) && !WIFSIGNALED(status)); //exit or killed by signal

        //terminated because of status
        if (WIFEXITED(status))
        {

            sprintf(str, "%d", WEXITSTATUS(status));
            setenv("STATUS", str, 1);
        }
        //terminate because signal
        else
        {
            ter = 1;
            sprintf(str, "%d", WTERMSIG(status));
            setenv("SIG", str, 1);
        }
    }
    //return true when it runs without error
    return 1;
}

void expandDollar(char **argument_array, pid_t parent_pid)
{

    int index = 0;
    //expand $$ in a command into the pid of the shell itself
    while (argument_array[index])
    {
        if (strstr(argument_array[index], "$$"))
        {
            
            int j, k;
            //break where the "$$" is, store the index to j
            for (j = 0; j < strlen(argument_array[index]); j++)
            {
                if (argument_array[index][j] == '$' && argument_array[index][j + 1] == '$')
                {
                    break;
                }
            }


            char pid_string[30];
            sprintf(pid_string, "%ld", (long)(parent_pid));
            //get the length of result
            int result_length = strlen(pid_string) + strlen(argument_array[index]) - 1;
            char result[result_length];

            //store chars before "$$" to result
            for (k = 0; k < j; k++)
            {
                result[k] = argument_array[index][k];
            }

            //expand $$
            for (k = 0; k < strlen(pid_string); k++)
            {
                result[k + j] = pid_string[k];
            }
            //store chars after "$$"
            k=k+j;
            j += 2;

            for (; k < result_length; k++)
            {
                result[k] = argument_array[index][j];
                j++;
            }

            result[k] = '\0';


            //copy the result to arugument array
            strcpy(argument_array[index], result);
        }
        index++;
    }

}

int execute(char **argument_array, pid_t parent_pid, int terminate, int num_background, long *backgroundPID)
{
    int index = 0;
    //when argument is empty
    if (argument_array[0] == NULL || argument_array[0][0] == '#')
    {
        return 1;
    }
    //printf("argument[0 = %s\n",argument_array[0]);
    expandDollar(argument_array, parent_pid);
    //printf("argument[0 = %s\n",argument_array[0]);
    

    if (strcmp(argument_array[0], "exit") == 0)
    {
        return bi_exit();
    }
    else if (strcmp(argument_array[0], "status") == 0)
    {
        return bi_status(argument_array);
    }
    else if (strcmp(argument_array[0], "cd") == 0)
    {
        return bi_cd(argument_array);
    }

    return launch(argument_array, terminate, num_background, backgroundPID);
}

void kill_zombies(int num_background, long *backgroundPID)
{
    int status = 0, background_status = 0, i;
    pid_t pid, wpid;
    char *last_sig = getenv("SIG");
    char str[12];
    for (i = 0; i < num_background; i++)
    {
        pid = backgroundPID[i];

        //if zombie find, kill it
        if (wpid = waitpid(pid, &status, WNOHANG))
        {
            int temp = i;
            for (temp; temp < num_background - 1; temp++)
            {
                backgroundPID[temp] = backgroundPID[temp + 1];
            }
            i--;
            num_background--;
            // if zombies exist, set STATUS and call status
            if (WIFEXITED(status))
            {          
                sprintf(str, "%d", WEXITSTATUS(status));
                setenv("STATUS", str, 1);
            }
            // set SIG and call status
            else
            { 
                sprintf(str, "%d", WTERMSIG(status));
                setenv("SIG", str, 1);
            }
            printf("background pid %ld is done: ", (long)(pid)); //print zombies pid
            bi_status(NULL);
            setenv("SIG", last_sig, 1); //set SIG back
            fflush(stdout);


        }
    }
}

//signal handler for SIGTSTP
void TSTP_handle(int signal)
{
    if (fg)
    {
        fg = 0;
        char *message = "Exiting foreground-only mode\n: ";
        write(STDOUT_FILENO, message, 32);
    }
    else
    {
        fg = 1;
        char *message = "Entering foreground-only mode\n: ";
        write(STDOUT_FILENO, message, 52);
    }
}

int bi_exit(int num_background, long *backgroundPID)
{
    int i;
    pid_t pid;
    // kill zombie process
    for (i = 0; i < num_background; i++)
    {
        pid = backgroundPID[i];
        kill(pid, SIGTERM);
    }

    return 0;
}

int bi_cd(char **argument_array)
{
    setenv("STATUS", "0", 1);
    //only cd, reutrn to HOME directory
    if (argument_array[1] == NULL)
    {
        argument_array[1] = getenv("HOME");
    }
    //if chdir failed
    if (chdir(argument_array[1]) != 0)
    { //chdir() doing the cd to the directory we get from input
        perror("smallsh");
        fflush(stdout);
        setenv("STATUS", "1", 1);
    }
    return 1;
}

int bi_status(char **argument_array)
{

    char *sig_p = getenv("SIG");
    if (strcmp(sig_p, "0"))
    {
        printf("Terminate, Signal %s\n", sig_p);
    }
    else
    {
        printf("Exit status %s\n", getenv("STATUS"));
    }
    fflush(stdout);
    return 1;
}
