#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>

struct Room
{
    char* name;
    int type;
    int connectionNum;
    int connectArr[7];
};

void create_rooms(char** roomNames, char* path, struct Room* roomarr);
int is_connected(struct Room* , int , int );
void connect_rooms(struct Room* roomarr,char* path);
void connect (struct Room* roomarr, int room1Index, int room2Index, char* directoryPath);
void write_rooms(struct Room*, char*);
void roomType(struct Room* roomarr);



int main(){
    FILE *fp;
    char temp[100];
    time_t t;
   /* Intializes random number generator */
    srand((unsigned) time(&t));

    //create the directory
    int PID = getpid();
    sprintf(temp,"zhanjunz.rooms.%d",PID);
    while(mkdir(temp,0777) != 0){
        PID = rand();
        sprintf(temp,"zhanjunz.rooms.%d",PID);
    }
    // create roomNames
    char* roomNames[10];
    roomNames[0] = "One";
    roomNames[1] = "Two";
    roomNames[2] = "Three";
    roomNames[3] = "Four";
    roomNames[4] = "Five";
    roomNames[5] = "Six";
    roomNames[6] = "Seven";
    roomNames[7] = "Eight";
    roomNames[8] = "Nine";
    roomNames[9] = "Ten";

    struct Room roomarr[7];
    int i,j;
    for( i = 0; i < 7; i++)
    {
        roomarr[i].connectionNum = 1;
        roomarr[i].type = 0;

        for(j = 0; j<7;j++)
            roomarr[i].connectArr[j] = 0;
        roomarr[i].connectArr[i] = 1;
    }
    
    create_rooms(roomNames,temp,roomarr);
    connect_rooms(roomarr,temp);
    roomType(roomarr);
    write_rooms(roomarr,temp);


    // for(j = 0; j<7;j++){
    //     printf("%s\n",roomarr[j].name);
    //     printf("connection Num = %d\n",roomarr[j].connectionNum);
    //     for(i = 0; i < 7;i++)
    //         printf("%d ",roomarr[j].connectArr[i]);
    // printf("\n");
    // }



}

void write_rooms(struct Room* roomarr, char*directoryPath){
    FILE*f;
    int i, j,k;
    char roomPath[100],fileContext[100];
    //write rooms
    for(i=0;i<7;i++){
        //open ith room and write its connection rooms
        sprintf(roomPath,"./%s/%s_room",directoryPath,roomarr[i].name);   
        f = fopen(roomPath,"a");
        k=1;
        for(j=0;j<7;j++){

            if(roomarr[i].connectArr[j] == 1 && i!=j){
                sprintf(fileContext,"CONNECTION %d: %s\n", k , roomarr[j].name );
                fputs(fileContext,f);
                k++;
            }
        }
        switch (roomarr[i].type)
        {
            case 1:
                sprintf(fileContext,"ROOM TYPE: START_ROOM\n");
                break;

            case 2:
                sprintf(fileContext,"ROOM TYPE: END_ROOM\n");
                break;

            default:
                sprintf(fileContext,"ROOM TYPE: MID_ROOM\n");
                break;
        }

        fputs(fileContext,f);
        fclose(f);    
    }
}

void create_rooms(char** roomNames, char* path, struct Room* roomarr){


    //loop run 7 tims to create seven files in Rooms directory
    
    int i =0,index;
    while(i < 7)
    {
        char temp[100];
        index = rand()%10;
        sprintf(temp,"./%s/%s_room",path,roomNames[index]);
        //create room file and write room name into file
        FILE* f;
        if (!(f = fopen(temp,"r"))) {
            roomarr[i].name = roomNames[index];
            f = fopen(temp,"w");
            sprintf(temp,"ROOM NAME: %s\n",roomNames[index]);
            fputs( temp , f);
            i++;
        }
        fclose(f);
    }
}

/* based on roomarr to check connection 
if these two room is connected return true */
int is_connected(struct Room* roomarr, int room1Index, int room2Index){
    int i ;
    int check;
    if(roomarr[room1Index].connectArr[room2Index] == 1)
        return 1;
    else
    {
        return 0;
    }

}

void connect_rooms(struct Room* roomarr,char* path){

    int i = 0,randomNum,j;
    /*
    connect each room with another rooms 3 times
    */   
    for(j=0;j<3;j++){
        for( i = 0; i<7; i++){
            if(roomarr[i].connectionNum<4){
                //look for a random room to connect with ith room. 
                //check if these two room are connected, find a new randomNum and try to connect again
                do
                {
                    randomNum = rand()%7;
                } while (is_connected(roomarr,i,randomNum));
                //connect ith room with a random room which has not connected with ith room yet;
                connect(roomarr,i,randomNum,path);
            }
        }
    }
}

void connect (struct Room* roomarr, int room1Index, int room2Index, char* directoryPath){

    char fileContext[100],roomPath[100];

    //connect two rooms by changing the information in roomarr
    roomarr[room1Index].connectArr[room2Index] = 1;
    roomarr[room2Index].connectArr[room1Index] = 1;


    //write connection into files
    roomarr[room1Index].connectionNum++;
    roomarr[room2Index].connectionNum++;

}

void roomType(struct Room* roomarr){
    int i,randomNum;

    for(i=1;i<3;i++){

        do{
            randomNum = rand()%7;
        }while(roomarr[randomNum].type != 0);
        roomarr[randomNum].type = i;
    }
}