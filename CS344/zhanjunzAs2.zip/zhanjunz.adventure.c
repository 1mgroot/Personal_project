#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <time.h>
#include <pthread.h>

struct Room
{
    char name[30];
    int type;
    int connectionNum;
    int connectArr[7];
};

//create and initial mutex for time
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_t getT;

// read and store all directories names

// find most resently modified directories
char *find_dir(char*);
// read 7 room files and store information in roomarr
void readFiles(char *, struct Room *);
// game
void playGame(struct Room *);

//print roomarr[current] information
void printRoom(struct Room *, int);

//create currentTime.txt
void *getTime();

int main()
{
    char dir_name[100];
    struct Room roomarr[7];
    int i, j;

    //initial room array
    for (i = 0; i < 7; i++)
    {
        roomarr[i].connectionNum = 0;
        for (j = 0; j < 7; j++)
        {
            roomarr[i].connectArr[j] = 0;
        }
    }

    //get most recently modified directory
    
    find_dir(dir_name);
    printf("\n");
    //read files and store information in roomarr
    readFiles(dir_name, roomarr);
    //play the game
    playGame(roomarr);
}

char *find_dir(char* target)
{

    int dirCounter = 0, i, targetIndex;
    char dirName[100][100];

    struct dirent *de;
    struct stat sb;
    time_t t1;
    time_t t2;

    //read and store all directories names
    DIR *dr = opendir(".");
    while ((de = readdir(dr)) != NULL)
    {
        char *cPointer = strstr(de->d_name, "zhanjunz.rooms.");
        if (cPointer)
        {
            strcpy(dirName[dirCounter], de->d_name);
            dirCounter++;
        }
    }
    closedir(dr);

    //error handling for there is no room directory
    if (dirCounter == 0)
    {
        printf("Error: no room directory found\n");
        return NULL;
    }

    // find most resently modified directories
    t1 = sb.st_mtime;
    targetIndex = 0;
    for (i = 0; i < dirCounter; i++)
    {
        t2 = sb.st_mtime;
        if (t2 > t1)
        {
            targetIndex = i;
            t1 = t2;
        }
    }
    strcpy(target, dirName[targetIndex]);
    return target;
}

void readFiles(char *dir_name, struct Room *roomarr)
{
    struct dirent *dire;
    DIR *dir = opendir(dir_name);
    int i = 0, j;
    char roomFileNames[7][50], temp[100], word1[50], word2[50], word3[50];

    //store all files name in the directory
    while ((dire = readdir(dir)) != NULL)
    {
        char *pt = strstr(dire->d_name, "_room");
        if (pt)
        {
            strcpy(roomFileNames[i], dire->d_name);
            i++;
        }
    }
    closedir(dir);

    //read 7 rooms and store information into struct Room
    i = 0;
    FILE *f;

    while (i < 7)
    {
        sprintf(temp, "./%s/%s", dir_name, roomFileNames[i]);
        f = fopen(temp, "r");

        //get room names and remmber the index of them, they will be the new index in roomarr
        fscanf(f, "%s %s %s", word1, word2, word3);
        strcpy(roomarr[i].name, word3);

        // read connetion until the first word is not CONNECTION
        do
        {
            roomarr[i].connectionNum++;
            fscanf(f, "%s %s %s", word1, word2, word3);
            for (j = 0; j < 7; j++)
            {
                if (strstr(roomFileNames[j], word3))
                {
                    roomarr[i].connectArr[j] = 1;
                }
            }
        } while (strcmp(word1, "CONNECTION") == 0);

        //read and store type;
        fscanf(f, "%s %s %s", word1, word2, word3);
        if (strcmp(word3, "START_ROOM") == 0)
        {
            roomarr[i].type = 1;
        }
        else if (strcmp(word3, "END_ROOM") == 0)
        {
            roomarr[i].type = 2;
        }
        else
        {
            roomarr[i].type = 0;
        }
        i++;
        fclose(f);
    }
}

void playGame(struct Room *roomarr)
{
    int numCharsEntered = -5; // How many chars we entered
    int currChar = -5;        // Tracks where we are when we print out every char
    size_t bufferSize = 0;    // Holds how large the allocated buffer is
    char *lineEntered = NULL;
    int i, j, targetIndex;
    // find start room as current room, endroom as end
    int currentIndex, endIndex, stepCounter;
    char roomHistory[50][10];
    char c;
    for (i = 0; i < 7; i++)
    {
        //currentIndex =  start room index
        if (roomarr[i].type == 1)
            currentIndex = i;

        //endIndex = end room index
        if (roomarr[i].type == 2)
            endIndex = i;
    }

    //initial targetIndex and first step
    targetIndex = currentIndex;
    stepCounter = 0;

    do
    {

        //print roomarr[current] information
        printRoom(roomarr, currentIndex);
        // get input from user
        printf("WHERE TO? > ");
        numCharsEntered = getline(&lineEntered, &bufferSize, stdin); // Get a line from the user
        lineEntered[numCharsEntered - 1] = '\0';
        printf("\n");

        while (strcmp(lineEntered, "time") == 0)
        {
            pthread_create(&getT, NULL, &getTime, NULL); //create second thread, getTime write the currentTime.txt
            pthread_join(getT, NULL);                    //join second thread
            pthread_mutex_lock(&lock);                   //mutex lock
            FILE *f;
            f = fopen("currentTime.txt", "r");
            //print the content of currentTime.txt
            c = fgetc(f);
            while (c != EOF)
            {
                printf("%c", c);
                c = fgetc(f);
            }
            fclose(f);
            pthread_mutex_unlock(&lock); //mutex unlock

            printf("\n");
            printf("WHERE TO? > "); //print ask for input message and get a new input
            numCharsEntered = getline(&lineEntered, &bufferSize, stdin);
            lineEntered[numCharsEntered - 1] = '\0';
            printf("\n");
        }

        i = 0;
        for (j = 0; j < 7; j++)
        {
            // check the room player choose is connected with current room  [Loop]
            // current room = the room player choose
            if (roomarr[currentIndex].connectArr[j] == 1 && strcmp(roomarr[j].name, lineEntered) == 0)
            {
                // store the room name into roomHistory array
                strcpy(roomHistory[stepCounter], roomarr[j].name);
                // step counter ++
                stepCounter++;
                targetIndex = j;
                i = 1;
            }
        }
        if (i == 0)
        {
            printf("HUH? I DON’T UNDERSTAND THAT ROOM. TRY AGAIN.\n\n");
        }
        currentIndex = targetIndex;
        // check if current room == END_ROOM
    } while (currentIndex != endIndex);

    printf("YOU HAVE FOUND THE END ROOM. CONGRATULATIONS!\nYOU TOOK %d STEPS. YOUR PATH TO VICTORY WAS:\n", stepCounter);

    for (i = 0; i < stepCounter; i++)
    {
        printf("%s\n", roomHistory[i]);
    }
    free(lineEntered);
}

void printRoom(struct Room *roomarr, int currentIndex)
{
    int i, j = 1;
    //print current location
    printf("CURRENT LOCATION: %s\n", roomarr[currentIndex].name);

    //print connection
    printf("POSSIBLE CONNECTION: ");
    for (i = 0; i < 7; i++)
    {
        if (roomarr[currentIndex].connectArr[i] == 1)
        {
            printf("%s,", roomarr[i].name);
            j++;
        }
    }
    printf("\n");
}

void *getTime()
{
    //lock mutex
    pthread_mutex_lock(&lock);

    //write time into currentime.txt
    FILE *fp;
    fp = fopen("currentTime.txt", "w");
    time_t t;
    struct tm *tmp;
    char currentT[50];
    time(&t);
    tmp = localtime(&t);
    strftime(currentT, sizeof(currentT), "%l:%M%P, %A, %B %e, %G\n", tmp);
    fputs(currentT, fp);
    fclose(fp);
    //unlock mutex
    pthread_mutex_unlock(&lock);
    return NULL;
}