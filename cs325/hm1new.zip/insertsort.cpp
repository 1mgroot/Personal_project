#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;
//sorting algorithem from other course

void insertion_sort(int *, int);

int main(){

	int line1Num;
	ifstream input;
	input.open("data.txt");

	ofstream output;
	output.open("insert.txt");

	if(!input.is_open()){
	cout << "Invalid Filename\n";
	return 0;
	}

	while(!input.eof()){
		input >> line1Num;

		int* line1 = new int[line1Num];
		for(int i = 0; i < line1Num; i++){
			input >> line1[i];
		}

		insertion_sort(line1,line1Num);
		
		for(int i = 0; i < line1Num; i++)
			output << line1[i]<<" ";
		output << "\n";
		delete line1;
	}

	input.close();
	output.close();
	

}


void insertion_sort(int *nums, int size) {
   int i, j;
   int temp;

   //What does this loop do?
   for(i=0; i<size; i++) {
      temp=nums[i]; 
      //What does this loop do?
      for(j=i; j>0 && nums[j-1]>temp; j--) 
	 nums[j]=nums[j-1];
      //What does this statment do?
      nums[j]=temp;
   }
}