#include <iostream>
#include <fstream>
#include <cstdlib>
#include <algorithm> 

using namespace std; 




void insertion_sort(int *, int);
void testTime(int);


int main(){

    srand(time(NULL));
    int size=125;
    for(int i=0;i<10;i++){
    size = size*2;
    testTime(size);
    }

}

void testTime(int size){
	int* line1 = new int[size];
	for(int i = 0; i < size; i++){
		line1[i] = rand()%10000;
	}

    float t1,t2;
    t1=clock();
	insertion_sort(line1,size);
	t2=clock();

    float t = (t2-t1)/CLOCKS_PER_SEC;   //http://www.cplusplus.com/forum/beginner/14666/
    cout << "size = " << size << " run time = "<< t<<"s"<<endl;
	delete line1;
}

void insertion_sort(int *nums, int size) {
   int i, j;
   int temp;

   //What does this loop do?
   for(i=0; i<size; i++) {
      temp=nums[i]; 
      //What does this loop do?
      for(j=i; j>0 && nums[j-1]>temp; j--) 
	 nums[j]=nums[j-1];
      //What does this statment do?
      nums[j]=temp;
   }
}