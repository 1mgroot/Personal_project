

#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;
////sorting algorithem from other course

void merge(int*, int, int, int);
void merge_sort(int *,int,int);

int main(){

	int line1Num;
	ifstream input;
	input.open("data.txt");

	ofstream output;
	output.open("merge.txt");

	if(!input.is_open()){
	cout << "Invalid Filename\n";
	return 0;
	}

	while(!input.eof()){
		input >> line1Num;

		int* line1 = new int[line1Num];
		for(int i = 0; i < line1Num; i++){
			input >> line1[i];
		}

		merge_sort(line1,0,line1Num-1);
		
		for(int i = 0; i < line1Num; i++)
			output << line1[i]<<" ";
		output << "\n";
		delete line1;
	}

	input.close();
	output.close();
	

}

void merge(int *nums, int left, int mid, int right){
   int i, j, lower_half, upper_half;
   int temp[(right-left)+1];

   lower_half=left;  
   upper_half=mid+1;  

   for(i=0; (lower_half<=mid)&&(upper_half<=right); i++){

      if(nums[lower_half]<=nums[upper_half]){
	 temp[i]=nums[lower_half];
	 lower_half++;
      }

      else{
	 temp[i]=nums[upper_half];
	 upper_half++;
      }
   }


   if(lower_half>mid)
      for(j=upper_half;j<=right;j++, i++)
	 temp[i]=nums[j];

   else
      for(j=lower_half;j<=mid;j++, i++)
	 temp[i]=nums[j];


   for(j=0,i=left;i<=right;i++,j++)
      nums[i]=temp[j];
}


void merge_sort(int *nums, int left, int right) {
   int mid; 
   if(left<right) {
      mid=(right+left)/2;
      merge_sort(nums, left, mid); 
      merge_sort(nums, mid+1, right); 
      merge(nums, left, mid, right);  
   }
}

