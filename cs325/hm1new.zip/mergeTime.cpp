#include <iostream>
#include <fstream>
#include <cstdlib>
#include <algorithm> 

using namespace std; 





void merge(int*, int, int, int);
void merge_sort(int *,int,int);
void testTime(int);

int main(){

    srand(time(NULL));
    int size=1000;
    for(int i=0;i<11;i++){
    size = size*2;
    testTime(size);
    }

}

void testTime(int size){
	int* line1 = new int[size];
	for(int i = 0; i < size; i++){
		line1[i] = rand()%10000;
	}

    float t1,t2;
    t1=clock();
	merge_sort(line1,0,size-1);
	t2=clock();

    float t = (t2-t1)/CLOCKS_PER_SEC;   //http://www.cplusplus.com/forum/beginner/14666/
    cout << "size = " << size << " run time = "<< t<<"s"<<endl;
	delete line1;
}

void merge(int *nums, int left, int mid, int right){
   int i, j, lower_half, upper_half;
   int temp[(right-left)+1];

   lower_half=left;  
   upper_half=mid+1;  

   for(i=0; (lower_half<=mid)&&(upper_half<=right); i++){

      if(nums[lower_half]<=nums[upper_half]){
	 temp[i]=nums[lower_half];
	 lower_half++;
      }

      else{
	 temp[i]=nums[upper_half];
	 upper_half++;
      }
   }


   if(lower_half>mid)
      for(j=upper_half;j<=right;j++, i++)
	 temp[i]=nums[j];

   else
      for(j=lower_half;j<=mid;j++, i++)
	 temp[i]=nums[j];


   for(j=0,i=left;i<=right;i++,j++)
      nums[i]=temp[j];
}


void merge_sort(int *nums, int left, int right) {
   int mid; 
   if(left<right) {
      mid=(right+left)/2;
      merge_sort(nums, left, mid); 
      merge_sort(nums, mid+1, right); 
      merge(nums, left, mid, right);  
   }
}

